import { useState } from "react";
import { authAPI } from "../api/client";

export default function Login({ onLogin }) {
  const [email, setEmail] = useState("admin@santiagogest.com");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErro("");
    try {
      const res = await authAPI.login(email, senha);
      localStorage.setItem("sg_token", res.data.access_token);
      localStorage.setItem("sg_usuario", JSON.stringify(res.data.usuario));
      onLogin(res.data.usuario);
    } catch (err) {
      setErro(err.response?.data?.detail || "Erro ao fazer login");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: "100vh", background: "#0D0F14", display: "flex",
      alignItems: "center", justifyContent: "center", fontFamily: "'Sora', sans-serif"
    }}>
      <div style={{
        background: "#1A1E2A", border: "1px solid #252A38", borderRadius: 20,
        padding: "40px 36px", width: 380, boxShadow: "0 32px 80px rgba(0,0,0,0.5)"
      }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 14, background: "#F97316",
            display: "flex", alignItems: "center", justifyContent: "center",
            margin: "0 auto 16px", fontSize: 24, fontWeight: 800, color: "#fff"
          }}>S</div>
          <h1 style={{ color: "#F1F5F9", fontSize: 22, fontWeight: 800, margin: 0 }}>SantiagoGest</h1>
          <p style={{ color: "#64748B", fontSize: 13, marginTop: 6 }}>Sistema de Gestão Empresarial</p>
        </div>

        <form onSubmit={handleLogin}>
          <div style={{ marginBottom: 14 }}>
            <label style={{ display: "block", color: "#94A3B8", fontSize: 11, fontWeight: 600, marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
              style={{ width: "100%", background: "#0D0F14", border: "1px solid #252A38", borderRadius: 8, padding: "11px 14px", color: "#F1F5F9", fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit" }}
            />
          </div>
          <div style={{ marginBottom: 20 }}>
            <label style={{ display: "block", color: "#94A3B8", fontSize: 11, fontWeight: 600, marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Senha</label>
            <input type="password" value={senha} onChange={e => setSenha(e.target.value)} required
              style={{ width: "100%", background: "#0D0F14", border: "1px solid #252A38", borderRadius: 8, padding: "11px 14px", color: "#F1F5F9", fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit" }}
            />
          </div>
          {erro && <div style={{ background: "rgba(239,68,68,0.12)", border: "1px solid rgba(239,68,68,0.3)", borderRadius: 8, padding: "10px 14px", color: "#EF4444", fontSize: 13, marginBottom: 16 }}>{erro}</div>}
          <button type="submit" disabled={loading} style={{
            width: "100%", background: "#F97316", border: "none", borderRadius: 8,
            padding: "12px", color: "#fff", fontWeight: 700, fontSize: 14, cursor: loading ? "not-allowed" : "pointer",
            opacity: loading ? 0.7 : 1, fontFamily: "inherit"
          }}>
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>
      </div>
    </div>
  );
}
