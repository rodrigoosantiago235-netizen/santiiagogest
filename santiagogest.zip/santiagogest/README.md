# SantiagoGest 🏪

Sistema de Gestão Empresarial completo com PDV, Estoque, Financeiro e Relatórios.

---

## 🗂️ Estrutura do Projeto

```
santiagogest/
├── backend/               # Python + FastAPI
│   ├── main.py            # App principal + rotas
│   ├── database.py        # Conexão PostgreSQL
│   ├── models.py          # Modelos do banco (SQLAlchemy)
│   ├── schemas.py         # Validação de dados (Pydantic)
│   ├── auth.py            # JWT + bcrypt
│   ├── seed.py            # Dados iniciais (admin + categorias)
│   ├── requirements.txt
│   ├── Dockerfile
│   ├── Procfile           # Para Railway
│   └── routes/
│       ├── auth.py
│       ├── produtos.py
│       ├── estoque.py
│       ├── vendas.py
│       ├── financeiro.py
│       └── relatorios.py
├── frontend/              # React + Vite
│   ├── src/
│   │   ├── App.jsx        # App completo (layout + módulos)
│   │   ├── main.jsx       # Entry point
│   │   ├── pages/
│   │   │   └── Login.jsx
│   │   └── api/
│   │       └── client.js  # Axios + interceptors
│   ├── index.html
│   ├── vite.config.js
│   ├── package.json
│   └── Dockerfile
└── docker-compose.yml     # Sobe tudo com 1 comando
```

---

## 🚀 Opção 1: Rodar com Docker (Recomendado)

**Pré-requisitos:** Docker e Docker Compose instalados.

```bash
# 1. Clone ou extraia o projeto
cd santiagogest

# 2. Suba tudo
docker-compose up --build

# 3. Acesse
# Frontend: http://localhost:3000
# API docs: http://localhost:8000/docs
```

Login padrão:
- **Email:** admin@santiagogest.com
- **Senha:** admin123

---

## 💻 Opção 2: Rodar Localmente (sem Docker)

### Pré-requisitos
- Python 3.11+
- Node.js 18+
- PostgreSQL 14+

### Backend

```bash
cd backend

# Criar ambiente virtual
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows

# Instalar dependências
pip install -r requirements.txt

# Configurar variáveis de ambiente
cp .env.example .env
# Edite o .env com sua senha do PostgreSQL

# Criar banco no PostgreSQL
psql -U postgres -c "CREATE DATABASE santiagogest;"

# Popular banco com dados iniciais
python seed.py

# Rodar servidor
uvicorn main:app --reload --port 8000
```

API disponível em: http://localhost:8000
Documentação: http://localhost:8000/docs

### Frontend

```bash
cd frontend

# Instalar dependências
npm install

# Configurar variáveis
cp .env.example .env
# VITE_API_URL=http://localhost:8000/api

# Rodar em desenvolvimento
npm run dev
```

Frontend disponível em: http://localhost:3000

---

## ☁️ Deploy no Railway

### Backend

1. Acesse [railway.app](https://railway.app) e crie uma conta
2. Clique em **New Project → Deploy from GitHub**
3. Conecte o repositório e selecione a pasta `/backend`
4. Adicione um serviço **PostgreSQL** no mesmo projeto
5. Configure as variáveis de ambiente:

```
DATABASE_URL    = (Railway preenche automaticamente ao linkar o Postgres)
SECRET_KEY      = (gere com: python -c "import secrets; print(secrets.token_hex(32))")
```

6. O Railway detecta o `Procfile` e sobe automaticamente
7. Após o deploy, copie a URL pública (ex: `https://santiagogest-api.up.railway.app`)
8. Acesse `<sua-url>/docs` para confirmar que a API está no ar
9. Execute o seed via Railway Shell:
   ```bash
   python seed.py
   ```

### Frontend

1. Crie outro serviço no mesmo projeto Railway
2. Aponte para a pasta `/frontend`
3. Configure:

```
VITE_API_URL = https://sua-url-backend.up.railway.app/api
```

4. Build command: `npm run build`
5. Start command: `npx serve dist`

---

## 📡 Endpoints da API

| Método | Rota | Descrição |
|--------|------|-----------|
| POST | /api/auth/login | Login |
| POST | /api/auth/registrar | Criar usuário |
| GET | /api/produtos | Listar produtos |
| POST | /api/produtos | Criar produto |
| GET | /api/estoque/alertas | Estoque crítico |
| POST | /api/estoque/movimentar | Entrada/saída |
| POST | /api/vendas | Registrar venda |
| GET | /api/vendas/resumo/hoje | Resumo do dia |
| GET | /api/financeiro | Lançamentos |
| GET | /api/financeiro/resumo/mensal | DRE mensal |
| GET | /api/relatorios/dashboard | KPIs |
| GET | /api/relatorios/produtos-mais-vendidos | Ranking |
| POST | /api/relatorios/notas-fiscais/{id}/emitir | Emitir NF-e |

Documentação completa (Swagger): `http://localhost:8000/docs`

---

## 🔐 Segurança

- Autenticação JWT com expiração de 8 horas
- Senhas criptografadas com bcrypt
- Middleware CORS configurado
- Roles de usuário: `admin`, `gerente`, `operador`

**Em produção, obrigatório:**
1. Altere o `SECRET_KEY` no `.env`
2. Troque a senha do admin após o primeiro login
3. Configure o CORS para o domínio do frontend (`allow_origins` em `main.py`)

---

## 🔌 Integração NF-e (SEFAZ)

O endpoint `/api/relatorios/notas-fiscais/{venda_id}/emitir` está preparado para integração.

Bibliotecas recomendadas:
- **FocusNFe** (API SaaS, mais simples): https://focusnfe.com.br
- **pynfe** (open source): `pip install pynfe`

Adicione as credenciais no `.env`:
```
SEFAZ_TOKEN=seu_token
SEFAZ_AMBIENTE=homologacao
```

---

## 🛠️ Tecnologias

| Camada | Tecnologia |
|--------|-----------|
| Backend | Python 3.12 + FastAPI |
| ORM | SQLAlchemy 2.0 |
| Banco | PostgreSQL 16 |
| Auth | JWT + bcrypt |
| Frontend | React 18 + Vite |
| HTTP Client | Axios |
| Containers | Docker + Docker Compose |
| Deploy | Railway |
