import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8000/api";

const api = axios.create({
  baseURL: API_URL,
  headers: { "Content-Type": "application/json" },
});

// Injeta token em todas as requisições
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("sg_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Redireciona para login se token expirar
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem("sg_token");
      localStorage.removeItem("sg_usuario");
      window.location.href = "/login";
    }
    return Promise.reject(err);
  }
);

// ─── AUTH ──────────────────────────────────────────────────────
export const authAPI = {
  login: (email, senha) => api.post("/auth/login", { email, senha }),
  me: () => api.get("/auth/me"),
  alterarSenha: (dados) => api.put("/auth/alterar-senha", dados),
};

// ─── PRODUTOS ──────────────────────────────────────────────────
export const produtosAPI = {
  listar: (params) => api.get("/produtos", { params }),
  obter: (id) => api.get(`/produtos/${id}`),
  criar: (dados) => api.post("/produtos", dados),
  atualizar: (id, dados) => api.put(`/produtos/${id}`, dados),
  desativar: (id) => api.delete(`/produtos/${id}`),
  categorias: () => api.get("/produtos/categorias/lista"),
  criarCategoria: (nome) => api.post("/produtos/categorias/nova", { nome }),
};

// ─── ESTOQUE ───────────────────────────────────────────────────
export const estoqueAPI = {
  alertas: () => api.get("/estoque/alertas"),
  movimentar: (dados) => api.post("/estoque/movimentar", dados),
  historico: (produto_id) => api.get(`/estoque/historico/${produto_id}`),
  atualizarMinimo: (produto_id, dados) => api.put(`/estoque/${produto_id}/minimo`, dados),
};

// ─── VENDAS ────────────────────────────────────────────────────
export const vendasAPI = {
  criar: (dados) => api.post("/vendas", dados),
  listar: (params) => api.get("/vendas", { params }),
  obter: (id) => api.get(`/vendas/${id}`),
  cancelar: (id) => api.put(`/vendas/${id}/cancelar`),
  resumoHoje: () => api.get("/vendas/resumo/hoje"),
};

// ─── FINANCEIRO ────────────────────────────────────────────────
export const financeiroAPI = {
  listar: (params) => api.get("/financeiro", { params }),
  criar: (dados) => api.post("/financeiro", dados),
  pagar: (id) => api.put(`/financeiro/${id}/pagar`),
  deletar: (id) => api.delete(`/financeiro/${id}`),
  resumoMensal: (mes, ano) => api.get("/financeiro/resumo/mensal", { params: { mes, ano } }),
  resumoAnual: (ano) => api.get("/financeiro/resumo/anual", { params: { ano } }),
};

// ─── RELATÓRIOS ────────────────────────────────────────────────
export const relatoriosAPI = {
  dashboard: () => api.get("/relatorios/dashboard"),
  maisVendidos: (params) => api.get("/relatorios/produtos-mais-vendidos", { params }),
  vendasPeriodo: (params) => api.get("/relatorios/vendas-por-periodo", { params }),
  posicaoEstoque: () => api.get("/relatorios/posicao-estoque"),
  notasFiscais: (params) => api.get("/relatorios/notas-fiscais", { params }),
  emitirNFe: (venda_id) => api.post(`/relatorios/notas-fiscais/${venda_id}/emitir`),
};

export default api;
