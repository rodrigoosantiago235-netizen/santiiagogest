import { useState, useEffect } from "react";
import Login from "./pages/Login";
import { relatoriosAPI, vendasAPI, produtosAPI, financeiroAPI, estoqueAPI } from "./api/client";

// ─── THEME ─────────────────────────────────────────────────────
const t = {
  bg: "#0D0F14", sidebar: "#13161E", card: "#1A1E2A", cardHover: "#1F2535",
  border: "#252A38", accent: "#F97316", accentSoft: "rgba(249,115,22,0.12)",
  blue: "#3B82F6", blueSoft: "rgba(59,130,246,0.12)",
  green: "#22C55E", greenSoft: "rgba(34,197,94,0.12)",
  red: "#EF4444", redSoft: "rgba(239,68,68,0.12)",
  purple: "#A855F7", purpleSoft: "rgba(168,85,247,0.12)",
  text: "#F1F5F9", textMuted: "#64748B", textSub: "#94A3B8",
};

const Icon = ({ name, size = 18, color = "currentColor" }) => {
  const icons = {
    dashboard: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>,
    pdv: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>,
    estoque: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>,
    financeiro: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>,
    relatorios: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
    menu: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>,
    logout: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>,
    user: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
    plus: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
    trash: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg>,
    search: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
    check: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>,
    bell: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>,
    close: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
    arrow_up: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>,
    arrow_down: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>,
    edit: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
    print: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>,
    barcode: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><path d="M3 5v14M7 5v14M11 5v14M15 5v14M19 5v14"/></svg>,
    chart: <svg width={size} height={size} fill="none" stroke={color} strokeWidth="2" viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>,
  };
  return icons[name] || null;
};

const Badge = ({ label, color, bg }) => (
  <span style={{ padding: "2px 10px", borderRadius: 20, fontSize: 11, fontWeight: 600, color, background: bg, letterSpacing: "0.03em" }}>{label}</span>
);

const Modal = ({ title, onClose, children }) => (
  <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, backdropFilter: "blur(4px)" }}>
    <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 16, padding: 28, width: 480, maxWidth: "95vw", boxShadow: "0 24px 60px rgba(0,0,0,0.5)", maxHeight: "90vh", overflow: "auto" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
        <h3 style={{ color: t.text, margin: 0, fontSize: 17, fontWeight: 700 }}>{title}</h3>
        <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer" }}><Icon name="close" size={18} color={t.textMuted} /></button>
      </div>
      {children}
    </div>
  </div>
);

const Field = ({ label, value, onChange, type = "text", placeholder, options }) => (
  <div style={{ marginBottom: 14 }}>
    <label style={{ display: "block", color: t.textSub, fontSize: 11, fontWeight: 600, marginBottom: 6, letterSpacing: "0.05em", textTransform: "uppercase" }}>{label}</label>
    {options ? (
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ width: "100%", background: t.bg, border: `1px solid ${t.border}`, borderRadius: 8, padding: "10px 12px", color: t.text, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit" }}>
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    ) : (
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{ width: "100%", background: t.bg, border: `1px solid ${t.border}`, borderRadius: 8, padding: "10px 12px", color: t.text, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit" }} />
    )}
  </div>
);

const Btn = ({ label, onClick, color = t.accent, icon, fullWidth, variant = "solid", disabled }) => (
  <button onClick={onClick} disabled={disabled} style={{
    background: variant === "solid" ? color : "transparent", border: `1px solid ${color}`,
    color: variant === "solid" ? "#fff" : color, borderRadius: 8, padding: "10px 18px",
    fontWeight: 600, fontSize: 13, cursor: disabled ? "not-allowed" : "pointer",
    display: "flex", alignItems: "center", gap: 6,
    width: fullWidth ? "100%" : "auto", justifyContent: fullWidth ? "center" : "flex-start",
    fontFamily: "inherit", opacity: disabled ? 0.5 : 1
  }}>
    {icon && <Icon name={icon} size={15} color={variant === "solid" ? "#fff" : color} />}
    {label}
  </button>
);

// ─── DASHBOARD ───────────────────────────────────────────────
const Dashboard = () => {
  const [dados, setDados] = useState(null);
  const [topProd, setTopProd] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([relatoriosAPI.dashboard(), relatoriosAPI.maisVendidos({ limit: 5 })])
      .then(([dash, prod]) => {
        setDados(dash.data);
        setTopProd(prod.data);
      })
      .catch(() => setDados({}))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div style={{ color: t.textMuted, padding: 40, textAlign: "center" }}>Carregando dashboard...</div>;

  const kpis = [
    { label: "Faturamento Hoje", val: `R$ ${(dados?.faturamento_hoje || 0).toFixed(2)}`, color: t.accent },
    { label: "Vendas Hoje", val: `${dados?.vendas_hoje || 0} vendas`, color: t.blue },
    { label: "Saldo Caixa", val: `R$ ${(dados?.saldo_caixa || 0).toFixed(2)}`, color: t.green },
    { label: "Estoque Crítico", val: `${dados?.estoque_critico || 0} itens`, color: t.red },
  ];

  return (
    <div>
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ color: t.text, fontSize: 22, fontWeight: 800, margin: 0 }}>Dashboard</h2>
        <p style={{ color: t.textMuted, fontSize: 13, margin: "4px 0 0" }}>{new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 24 }}>
        {kpis.map((k, i) => (
          <div key={i} style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, padding: 22, position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: k.color }} />
            <div style={{ fontSize: 11, color: t.textMuted, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 8 }}>{k.label}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: t.text }}>{k.val}</div>
          </div>
        ))}
      </div>

      <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, padding: 22 }}>
        <div style={{ fontWeight: 700, color: t.text, fontSize: 15, marginBottom: 18 }}>Top Produtos do Dia</div>
        {topProd.length === 0 ? (
          <div style={{ color: t.textMuted, fontSize: 13 }}>Nenhuma venda registrada ainda.</div>
        ) : topProd.map((p, i) => (
          <div key={i} style={{ display: "flex", justifyContent: "space-between", marginBottom: 12, alignItems: "center" }}>
            <span style={{ color: t.textSub, fontSize: 13 }}>{p.nome}</span>
            <span style={{ color: t.accent, fontWeight: 700 }}>R$ {p.valor_total.toFixed(2)}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── PDV ─────────────────────────────────────────────────────
const PDV = () => {
  const [produtos, setProdutos] = useState([]);
  const [cart, setCart] = useState([]);
  const [search, setSearch] = useState("");
  const [pagModal, setPagModal] = useState(false);
  const [pagType, setPagType] = useState("dinheiro");
  const [recebido, setRecebido] = useState("");
  const [loading, setLoading] = useState(false);
  const [sucesso, setSucesso] = useState("");

  useEffect(() => {
    produtosAPI.listar({ busca: search, limit: 50 }).then(r => setProdutos(r.data)).catch(() => {});
  }, [search]);

  const total = cart.reduce((s, i) => s + i.preco_venda * i.qty, 0);
  const troco = parseFloat(recebido || 0) - total;

  const addItem = (p) => setCart(c => {
    const ex = c.find(x => x.id === p.id);
    if (ex) return c.map(x => x.id === p.id ? { ...x, qty: x.qty + 1 } : x);
    return [...c, { ...p, qty: 1 }];
  });

  const updateQty = (id, qty) => {
    if (qty <= 0) setCart(c => c.filter(x => x.id !== id));
    else setCart(c => c.map(x => x.id === id ? { ...x, qty } : x));
  };

  const finalizarVenda = async () => {
    setLoading(true);
    try {
      await vendasAPI.criar({
        tipo_pagamento: pagType,
        valor_recebido: parseFloat(recebido || total),
        itens: cart.map(i => ({ produto_id: i.id, quantidade: i.qty, preco_unitario: i.preco_venda }))
      });
      setCart([]);
      setPagModal(false);
      setRecebido("");
      setSucesso("Venda finalizada com sucesso!");
      setTimeout(() => setSucesso(""), 3000);
    } catch (err) {
      alert(err.response?.data?.detail || "Erro ao finalizar venda");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: 16, height: "calc(100vh - 120px)" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        {sucesso && <div style={{ background: t.greenSoft, border: `1px solid ${t.green}`, borderRadius: 10, padding: "12px 16px", color: t.green, fontWeight: 600 }}>{sucesso}</div>}
        <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, padding: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, background: t.bg, borderRadius: 10, padding: "10px 14px" }}>
            <Icon name="search" size={16} color={t.textMuted} />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar produto ou código de barras..."
              style={{ background: "none", border: "none", color: t.text, fontSize: 14, outline: "none", flex: 1, fontFamily: "inherit" }} />
          </div>
        </div>
        <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, overflow: "auto", flex: 1 }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead style={{ position: "sticky", top: 0, background: t.card }}>
              <tr>{["Produto", "Preço", "Estoque", ""].map(h => <th key={h} style={{ textAlign: "left", color: t.textMuted, fontSize: 11, fontWeight: 600, padding: "14px 16px 12px", textTransform: "uppercase", letterSpacing: "0.06em", borderBottom: `1px solid ${t.border}` }}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {produtos.map(p => {
                const estq = p.estoque?.quantidade ?? 0;
                return (
                  <tr key={p.id} style={{ borderBottom: `1px solid ${t.border}`, cursor: "pointer" }}
                    onMouseEnter={e => e.currentTarget.style.background = t.cardHover}
                    onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                    <td style={{ padding: "11px 16px", color: t.text, fontSize: 13 }}>{p.nome}</td>
                    <td style={{ color: t.accent, fontWeight: 700 }}>R$ {p.preco_venda.toFixed(2)}</td>
                    <td><Badge label={`${estq} ${p.unidade}`} color={estq <= 0 ? t.red : t.green} bg={estq <= 0 ? t.redSoft : t.greenSoft} /></td>
                    <td style={{ padding: "0 16px" }}>
                      <button onClick={() => addItem(p)} disabled={estq <= 0}
                        style={{ background: t.accentSoft, border: "none", borderRadius: 6, padding: "6px 12px", color: t.accent, fontWeight: 700, cursor: estq <= 0 ? "not-allowed" : "pointer", fontSize: 18, opacity: estq <= 0 ? 0.4 : 1 }}>+</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ padding: "18px 20px", borderBottom: `1px solid ${t.border}` }}>
          <div style={{ fontWeight: 700, color: t.text, fontSize: 16 }}>🛒 Carrinho</div>
          <div style={{ color: t.textMuted, fontSize: 12, marginTop: 2 }}>{cart.length} itens</div>
        </div>
        <div style={{ flex: 1, overflow: "auto", padding: "12px 16px" }}>
          {cart.length === 0 ? <div style={{ textAlign: "center", color: t.textMuted, marginTop: 40, fontSize: 13 }}>Nenhum item adicionado</div>
            : cart.map(item => (
              <div key={item.id} style={{ background: t.bg, borderRadius: 10, padding: "12px 14px", marginBottom: 8, border: `1px solid ${t.border}` }}>
                <div style={{ color: t.text, fontSize: 13, fontWeight: 600, marginBottom: 8 }}>{item.nome}</div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <button onClick={() => updateQty(item.id, item.qty - 1)} style={{ width: 24, height: 24, borderRadius: 6, border: `1px solid ${t.border}`, background: "none", color: t.text, cursor: "pointer" }}>−</button>
                    <span style={{ color: t.text, fontWeight: 700, width: 24, textAlign: "center" }}>{item.qty}</span>
                    <button onClick={() => updateQty(item.id, item.qty + 1)} style={{ width: 24, height: 24, borderRadius: 6, border: `1px solid ${t.border}`, background: "none", color: t.text, cursor: "pointer" }}>+</button>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <span style={{ color: t.accent, fontWeight: 700 }}>R$ {(item.preco_venda * item.qty).toFixed(2)}</span>
                    <button onClick={() => updateQty(item.id, 0)} style={{ background: "none", border: "none", cursor: "pointer" }}><Icon name="trash" size={15} color={t.red} /></button>
                  </div>
                </div>
              </div>
            ))}
        </div>
        <div style={{ padding: "16px 20px", borderTop: `1px solid ${t.border}` }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
            <span style={{ color: t.text, fontWeight: 800, fontSize: 18 }}>TOTAL</span>
            <span style={{ color: t.accent, fontWeight: 800, fontSize: 22 }}>R$ {total.toFixed(2)}</span>
          </div>
          <Btn label="Finalizar Venda" icon="check" fullWidth onClick={() => setPagModal(true)} disabled={cart.length === 0} />
          <button onClick={() => setCart([])} style={{ width: "100%", marginTop: 8, background: "none", border: `1px solid ${t.border}`, color: t.textMuted, borderRadius: 8, padding: "9px", cursor: "pointer", fontSize: 12, fontFamily: "inherit" }}>Limpar Carrinho</button>
        </div>
      </div>

      {pagModal && (
        <Modal title="Finalizar Venda" onClose={() => setPagModal(false)}>
          <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
            {[["dinheiro", "Dinheiro"], ["cartao_credito", "Crédito"], ["cartao_debito", "Débito"], ["pix", "PIX"]].map(([v, l]) => (
              <button key={v} onClick={() => setPagType(v)} style={{
                flex: 1, padding: "9px 4px", borderRadius: 8, cursor: "pointer",
                border: `1px solid ${pagType === v ? t.accent : t.border}`,
                background: pagType === v ? t.accentSoft : "none",
                color: pagType === v ? t.accent : t.textMuted,
                fontWeight: 600, fontSize: 11, fontFamily: "inherit"
              }}>{l}</button>
            ))}
          </div>
          <div style={{ background: t.bg, borderRadius: 10, padding: "14px 16px", marginBottom: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: t.textMuted }}>Total:</span>
              <span style={{ color: t.accent, fontWeight: 800, fontSize: 20 }}>R$ {total.toFixed(2)}</span>
            </div>
          </div>
          {pagType === "dinheiro" && (
            <>
              <Field label="Valor Recebido" value={recebido} onChange={setRecebido} type="number" placeholder="0,00" />
              {recebido && <div style={{ background: troco >= 0 ? t.greenSoft : t.redSoft, borderRadius: 8, padding: "10px 14px", marginBottom: 8 }}>
                <span style={{ color: troco >= 0 ? t.green : t.red, fontWeight: 700 }}>Troco: R$ {Math.abs(troco).toFixed(2)}</span>
              </div>}
            </>
          )}
          <Btn label={loading ? "Processando..." : "Confirmar Pagamento"} icon="check" fullWidth onClick={finalizarVenda} disabled={loading} />
        </Modal>
      )}
    </div>
  );
};

// ─── ESTOQUE ─────────────────────────────────────────────────
const Estoque = () => {
  const [produtos, setProdutos] = useState([]);
  const [alertas, setAlertas] = useState([]);
  const [modal, setModal] = useState(false);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ nome: "", codigo_barras: "", preco_venda: "", preco_custo: "", quantidade_inicial: "", quantidade_minima: "" });

  const carregar = () => {
    setLoading(true);
    Promise.all([produtosAPI.listar({ busca: search }), estoqueAPI.alertas()])
      .then(([p, a]) => { setProdutos(p.data); setAlertas(a.data); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { carregar(); }, [search]);

  const salvar = async () => {
    try {
      await produtosAPI.criar({ ...form, preco_venda: +form.preco_venda, preco_custo: +form.preco_custo, quantidade_inicial: +form.quantidade_inicial, quantidade_minima: +form.quantidade_minima });
      setModal(false);
      setForm({ nome: "", codigo_barras: "", preco_venda: "", preco_custo: "", quantidade_inicial: "", quantidade_minima: "" });
      carregar();
    } catch (err) {
      alert(err.response?.data?.detail || "Erro ao salvar produto");
    }
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div>
          <h2 style={{ color: t.text, fontSize: 22, fontWeight: 800, margin: 0 }}>Estoque</h2>
          <p style={{ color: t.textMuted, fontSize: 13, margin: "4px 0 0" }}>{produtos.length} produtos · <span style={{ color: t.red }}>{alertas.length} com estoque baixo</span></p>
        </div>
        <Btn label="Novo Produto" icon="plus" onClick={() => setModal(true)} />
      </div>

      <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, padding: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, background: t.bg, borderRadius: 10, padding: "10px 14px", marginBottom: 16, width: 280 }}>
          <Icon name="search" size={15} color={t.textMuted} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar..." style={{ background: "none", border: "none", color: t.text, fontSize: 13, outline: "none", fontFamily: "inherit" }} />
        </div>
        {loading ? <div style={{ color: t.textMuted, padding: 20, textAlign: "center" }}>Carregando...</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>{["Produto", "Qtd", "Mín.", "Custo", "Venda", "Status"].map(h => <th key={h} style={{ textAlign: "left", color: t.textMuted, fontSize: 11, fontWeight: 600, padding: "0 0 12px", textTransform: "uppercase", letterSpacing: "0.06em" }}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {produtos.map(p => {
                const estq = p.estoque;
                const status = !estq ? "sem-estoque" : estq.status;
                return (
                  <tr key={p.id} style={{ borderTop: `1px solid ${t.border}` }}>
                    <td style={{ padding: "12px 0", color: t.text, fontSize: 13 }}>{p.nome}</td>
                    <td style={{ color: status === "critico" ? t.red : t.text, fontWeight: 700 }}>{estq?.quantidade ?? 0}</td>
                    <td style={{ color: t.textMuted, fontSize: 13 }}>{estq?.quantidade_minima ?? 0}</td>
                    <td style={{ color: t.textSub }}>R$ {p.preco_custo.toFixed(2)}</td>
                    <td style={{ color: t.accent, fontWeight: 700 }}>R$ {p.preco_venda.toFixed(2)}</td>
                    <td><Badge label={status === "normal" ? "Normal" : "Crítico"} color={status === "normal" ? t.green : t.red} bg={status === "normal" ? t.greenSoft : t.redSoft} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {modal && (
        <Modal title="Novo Produto" onClose={() => setModal(false)}>
          <Field label="Nome do Produto" value={form.nome} onChange={v => setForm(f => ({ ...f, nome: v }))} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <Field label="Código de Barras" value={form.codigo_barras} onChange={v => setForm(f => ({ ...f, codigo_barras: v }))} />
            <Field label="Quantidade Inicial" value={form.quantidade_inicial} onChange={v => setForm(f => ({ ...f, quantidade_inicial: v }))} type="number" />
            <Field label="Estoque Mínimo" value={form.quantidade_minima} onChange={v => setForm(f => ({ ...f, quantidade_minima: v }))} type="number" />
            <Field label="Custo (R$)" value={form.preco_custo} onChange={v => setForm(f => ({ ...f, preco_custo: v }))} type="number" />
            <Field label="Venda (R$)" value={form.preco_venda} onChange={v => setForm(f => ({ ...f, preco_venda: v }))} type="number" />
          </div>
          <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
            <Btn label="Cancelar" onClick={() => setModal(false)} color={t.border} variant="outline" />
            <Btn label="Salvar" icon="check" onClick={salvar} fullWidth />
          </div>
        </Modal>
      )}
    </div>
  );
};

// ─── FINANCEIRO ───────────────────────────────────────────────
const Financeiro = () => {
  const [lancamentos, setLancamentos] = useState([]);
  const [resumo, setResumo] = useState({});
  const [modal, setModal] = useState(false);
  const [tipo, setTipo] = useState("receita");
  const [form, setForm] = useState({ descricao: "", valor: "", categoria: "" });
  const [loading, setLoading] = useState(true);

  const carregar = () => {
    setLoading(true);
    Promise.all([financeiroAPI.listar({}), financeiroAPI.resumoMensal()])
      .then(([l, r]) => { setLancamentos(l.data); setResumo(r.data); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { carregar(); }, []);

  const salvar = async () => {
    try {
      await financeiroAPI.criar({ ...form, tipo, valor: +form.valor, pago: true });
      setModal(false);
      setForm({ descricao: "", valor: "", categoria: "" });
      carregar();
    } catch (err) {
      alert(err.response?.data?.detail || "Erro ao salvar");
    }
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <h2 style={{ color: t.text, fontSize: 22, fontWeight: 800, margin: 0 }}>Financeiro</h2>
        <Btn label="Novo Lançamento" icon="plus" onClick={() => setModal(true)} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14, marginBottom: 20 }}>
        {[
          { label: "Receitas", val: resumo?.receitas || 0, color: t.green },
          { label: "Despesas", val: resumo?.despesas || 0, color: t.red },
          { label: "Saldo", val: resumo?.saldo || 0, color: t.accent },
        ].map((c, i) => (
          <div key={i} style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, padding: 22 }}>
            <div style={{ fontSize: 11, color: t.textMuted, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 8 }}>{c.label}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: c.color }}>R$ {c.val.toFixed(2)}</div>
          </div>
        ))}
      </div>

      <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, padding: 22 }}>
        <div style={{ fontWeight: 700, color: t.text, fontSize: 15, marginBottom: 16 }}>Lançamentos</div>
        {loading ? <div style={{ color: t.textMuted, textAlign: "center", padding: 20 }}>Carregando...</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>{["Descrição", "Categoria", "Tipo", "Valor", ""].map(h => <th key={h} style={{ textAlign: "left", color: t.textMuted, fontSize: 11, fontWeight: 600, padding: "0 0 12px", textTransform: "uppercase", letterSpacing: "0.06em" }}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {lancamentos.map((l, i) => (
                <tr key={i} style={{ borderTop: `1px solid ${t.border}` }}>
                  <td style={{ padding: "12px 0", color: t.text, fontSize: 13 }}>{l.descricao}</td>
                  <td><Badge label={l.categoria || "Geral"} color={t.blue} bg={t.blueSoft} /></td>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                      <Icon name={l.tipo === "receita" ? "arrow_up" : "arrow_down"} size={13} color={l.tipo === "receita" ? t.green : t.red} />
                      <span style={{ color: l.tipo === "receita" ? t.green : t.red, fontSize: 12, fontWeight: 600 }}>{l.tipo === "receita" ? "Receita" : "Despesa"}</span>
                    </div>
                  </td>
                  <td style={{ color: l.tipo === "receita" ? t.green : t.red, fontWeight: 700 }}>
                    {l.tipo === "despesa" ? "- " : "+ "}R$ {l.valor.toFixed(2)}
                  </td>
                  <td>
                    <button onClick={async () => { await financeiroAPI.deletar(l.id); carregar(); }} style={{ background: "none", border: "none", cursor: "pointer" }}>
                      <Icon name="trash" size={14} color={t.red} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modal && (
        <Modal title="Novo Lançamento" onClose={() => setModal(false)}>
          <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
            {["receita", "despesa"].map(tp => (
              <button key={tp} onClick={() => setTipo(tp)} style={{
                flex: 1, padding: "10px", borderRadius: 8, cursor: "pointer",
                border: `1px solid ${tipo === tp ? (tp === "receita" ? t.green : t.red) : t.border}`,
                background: tipo === tp ? (tp === "receita" ? t.greenSoft : t.redSoft) : "none",
                color: tipo === tp ? (tp === "receita" ? t.green : t.red) : t.textMuted,
                fontWeight: 600, fontSize: 13, fontFamily: "inherit"
              }}>{tp === "receita" ? "✓ Receita" : "✕ Despesa"}</button>
            ))}
          </div>
          <Field label="Descrição" value={form.descricao} onChange={v => setForm(f => ({ ...f, descricao: v }))} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <Field label="Valor (R$)" value={form.valor} onChange={v => setForm(f => ({ ...f, valor: v }))} type="number" />
            <Field label="Categoria" value={form.categoria} onChange={v => setForm(f => ({ ...f, categoria: v }))} />
          </div>
          <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
            <Btn label="Cancelar" onClick={() => setModal(false)} color={t.border} variant="outline" />
            <Btn label="Salvar" icon="check" onClick={salvar} fullWidth />
          </div>
        </Modal>
      )}
    </div>
  );
};

// ─── RELATÓRIOS ───────────────────────────────────────────────
const Relatorios = () => {
  const [notas, setNotas] = useState([]);
  const [topProd, setTopProd] = useState([]);

  useEffect(() => {
    relatoriosAPI.notasFiscais().then(r => setNotas(r.data)).catch(() => {});
    relatoriosAPI.maisVendidos({ limit: 10 }).then(r => setTopProd(r.data)).catch(() => {});
  }, []);

  return (
    <div>
      <h2 style={{ color: t.text, fontSize: 22, fontWeight: 800, margin: "0 0 24px" }}>Relatórios & Nota Fiscal</h2>

      <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, padding: 22, marginBottom: 16 }}>
        <div style={{ fontWeight: 700, color: t.text, fontSize: 15, marginBottom: 18 }}>Produtos Mais Vendidos</div>
        {topProd.length === 0 ? <div style={{ color: t.textMuted, fontSize: 13 }}>Nenhum dado ainda.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>{["Produto", "Qtd Vendida", "Faturamento"].map(h => <th key={h} style={{ textAlign: "left", color: t.textMuted, fontSize: 11, fontWeight: 600, padding: "0 0 12px", textTransform: "uppercase", letterSpacing: "0.06em" }}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {topProd.map((p, i) => (
                <tr key={i} style={{ borderTop: `1px solid ${t.border}` }}>
                  <td style={{ padding: "12px 0", color: t.text, fontSize: 13 }}>{p.nome}</td>
                  <td style={{ color: t.textSub }}>{p.quantidade_total} un</td>
                  <td style={{ color: t.accent, fontWeight: 700 }}>R$ {p.valor_total.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, padding: 22 }}>
        <div style={{ fontWeight: 700, color: t.text, fontSize: 15, marginBottom: 18 }}>Notas Fiscais</div>
        {notas.length === 0 ? <div style={{ color: t.textMuted, fontSize: 13 }}>Nenhuma NF-e emitida ainda.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>{["Número", "Venda", "Status", "Data"].map(h => <th key={h} style={{ textAlign: "left", color: t.textMuted, fontSize: 11, fontWeight: 600, padding: "0 0 12px", textTransform: "uppercase", letterSpacing: "0.06em" }}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {notas.map((n, i) => (
                <tr key={i} style={{ borderTop: `1px solid ${t.border}` }}>
                  <td style={{ padding: "12px 0", color: t.textMuted, fontFamily: "monospace" }}>#{n.numero}</td>
                  <td style={{ color: t.textSub }}>Venda #{n.venda_id}</td>
                  <td><Badge label={n.status} color={n.status === "autorizada" ? t.green : n.status === "cancelada" ? t.red : t.accent} bg={n.status === "autorizada" ? t.greenSoft : n.status === "cancelada" ? t.redSoft : t.accentSoft} /></td>
                  <td style={{ color: t.textMuted, fontSize: 12 }}>{new Date(n.criado_em).toLocaleDateString("pt-BR")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

// ─── APP ─────────────────────────────────────────────────────
export default function App() {
  const [usuario, setUsuario] = useState(() => {
    try { return JSON.parse(localStorage.getItem("sg_usuario")); } catch { return null; }
  });
  const [page, setPage] = useState("dashboard");
  const [sideCollapsed, setSideCollapsed] = useState(false);

  const logout = () => {
    localStorage.removeItem("sg_token");
    localStorage.removeItem("sg_usuario");
    setUsuario(null);
  };

  if (!usuario) return <Login onLogin={setUsuario} />;

  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: "dashboard" },
    { id: "pdv", label: "PDV / Caixa", icon: "pdv" },
    { id: "estoque", label: "Estoque", icon: "estoque" },
    { id: "financeiro", label: "Financeiro", icon: "financeiro" },
    { id: "relatorios", label: "Relatórios", icon: "relatorios" },
  ];

  const pageMap = { dashboard: <Dashboard />, pdv: <PDV />, estoque: <Estoque />, financeiro: <Financeiro />, relatorios: <Relatorios /> };

  return (
    <div style={{ display: "flex", height: "100vh", background: t.bg, fontFamily: "'Sora', 'Segoe UI', sans-serif", overflow: "hidden" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&display=swap'); *{box-sizing:border-box} ::-webkit-scrollbar{width:4px} ::-webkit-scrollbar-thumb{background:#252A38;border-radius:2px}`}</style>

      <div style={{ width: sideCollapsed ? 64 : 220, background: t.sidebar, borderRight: `1px solid ${t.border}`, display: "flex", flexDirection: "column", transition: "width 0.25s ease", overflow: "hidden", flexShrink: 0 }}>
        <div style={{ padding: sideCollapsed ? "22px 14px" : "22px 20px", borderBottom: `1px solid ${t.border}`, display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: t.accent, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontWeight: 800, color: "#fff", fontSize: 16 }}>S</div>
          {!sideCollapsed && <div><div style={{ color: t.text, fontWeight: 800, fontSize: 14 }}>Santiago</div><div style={{ color: t.accent, fontWeight: 800, fontSize: 14, lineHeight: 1 }}>Gest</div></div>}
        </div>
        <nav style={{ flex: 1, padding: "16px 8px" }}>
          {navItems.map(item => {
            const active = page === item.id;
            return (
              <button key={item.id} onClick={() => setPage(item.id)} title={sideCollapsed ? item.label : ""} style={{
                width: "100%", display: "flex", alignItems: "center", gap: 10,
                padding: sideCollapsed ? "10px 12px" : "10px 14px", borderRadius: 10,
                border: "none", cursor: "pointer", marginBottom: 2,
                background: active ? t.accentSoft : "none",
                color: active ? t.accent : t.textMuted, fontFamily: "inherit"
              }}>
                <Icon name={item.icon} size={18} color={active ? t.accent : t.textMuted} />
                {!sideCollapsed && <span style={{ fontWeight: active ? 700 : 500, fontSize: 13 }}>{item.label}</span>}
              </button>
            );
          })}
        </nav>
        <div style={{ padding: "14px 12px", borderTop: `1px solid ${t.border}` }}>
          {!sideCollapsed && <div style={{ color: t.textSub, fontSize: 12, marginBottom: 8, paddingLeft: 4 }}>{usuario.nome}</div>}
          <button onClick={logout} title="Sair" style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: sideCollapsed ? "10px 12px" : "10px 14px", borderRadius: 10, border: "none", background: "none", color: t.red, cursor: "pointer", fontFamily: "inherit" }}>
            <Icon name="logout" size={16} color={t.red} />
            {!sideCollapsed && <span style={{ fontWeight: 600, fontSize: 13 }}>Sair</span>}
          </button>
        </div>
      </div>

      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ height: 58, borderBottom: `1px solid ${t.border}`, background: t.sidebar, display: "flex", alignItems: "center", paddingInline: 24, gap: 16, flexShrink: 0 }}>
          <button onClick={() => setSideCollapsed(c => !c)} style={{ background: "none", border: "none", cursor: "pointer" }}>
            <Icon name="menu" size={18} color={t.textMuted} />
          </button>
          <span style={{ color: t.textMuted, fontSize: 13 }}>{navItems.find(n => n.id === page)?.label}</span>
          <div style={{ flex: 1 }} />
          <div style={{ fontSize: 12, color: t.green, fontWeight: 600 }}>● Online</div>
        </div>
        <div style={{ flex: 1, overflow: "auto", padding: 24 }}>
          {pageMap[page]}
        </div>
      </div>
    </div>
  );
}
