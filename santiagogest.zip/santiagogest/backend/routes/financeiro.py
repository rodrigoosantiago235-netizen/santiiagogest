from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import List, Optional
from datetime import datetime, date
from database import get_db
import models, schemas
from auth import get_usuario_atual

router = APIRouter()

@router.get("/", response_model=List[schemas.LancamentoResponse])
def listar_lancamentos(
    tipo: Optional[str] = None,
    data_inicio: Optional[date] = None,
    data_fim: Optional[date] = None,
    pago: Optional[bool] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(get_usuario_atual)
):
    q = db.query(models.Lancamento)
    if tipo:
        q = q.filter(models.Lancamento.tipo == tipo)
    if pago is not None:
        q = q.filter(models.Lancamento.pago == pago)
    if data_inicio:
        q = q.filter(models.Lancamento.data >= datetime.combine(data_inicio, datetime.min.time()))
    if data_fim:
        q = q.filter(models.Lancamento.data <= datetime.combine(data_fim, datetime.max.time()))
    return q.order_by(models.Lancamento.data.desc()).offset(skip).limit(limit).all()

@router.post("/", response_model=schemas.LancamentoResponse)
def criar_lancamento(
    dados: schemas.LancamentoCreate,
    db: Session = Depends(get_db),
    usuario=Depends(get_usuario_atual)
):
    lancamento = models.Lancamento(
        descricao=dados.descricao,
        tipo=dados.tipo,
        valor=dados.valor,
        categoria=dados.categoria,
        pago=dados.pago,
        observacao=dados.observacao,
        usuario_id=usuario.id
    )
    db.add(lancamento)
    db.commit()
    db.refresh(lancamento)
    return lancamento

@router.put("/{lancamento_id}/pagar")
def marcar_pago(lancamento_id: int, db: Session = Depends(get_db), _=Depends(get_usuario_atual)):
    l = db.query(models.Lancamento).filter(models.Lancamento.id == lancamento_id).first()
    if not l:
        raise HTTPException(status_code=404, detail="Lançamento não encontrado")
    l.pago = True
    db.commit()
    return {"mensagem": "Marcado como pago"}

@router.delete("/{lancamento_id}")
def deletar_lancamento(lancamento_id: int, db: Session = Depends(get_db), _=Depends(get_usuario_atual)):
    l = db.query(models.Lancamento).filter(models.Lancamento.id == lancamento_id).first()
    if not l:
        raise HTTPException(status_code=404, detail="Lançamento não encontrado")
    db.delete(l)
    db.commit()
    return {"mensagem": "Excluído com sucesso"}

@router.get("/resumo/mensal")
def resumo_mensal(
    mes: int = Query(default=None),
    ano: int = Query(default=None),
    db: Session = Depends(get_db),
    _=Depends(get_usuario_atual)
):
    hoje = date.today()
    mes = mes or hoje.month
    ano = ano or hoje.year

    inicio = datetime(ano, mes, 1)
    if mes == 12:
        fim = datetime(ano + 1, 1, 1)
    else:
        fim = datetime(ano, mes + 1, 1)

    receitas = db.query(func.sum(models.Lancamento.valor)).filter(
        models.Lancamento.tipo == models.TipoLancamento.receita,
        models.Lancamento.data >= inicio,
        models.Lancamento.data < fim
    ).scalar() or 0

    despesas = db.query(func.sum(models.Lancamento.valor)).filter(
        models.Lancamento.tipo == models.TipoLancamento.despesa,
        models.Lancamento.data >= inicio,
        models.Lancamento.data < fim
    ).scalar() or 0

    return {
        "mes": mes, "ano": ano,
        "receitas": receitas,
        "despesas": despesas,
        "saldo": receitas - despesas
    }

@router.get("/resumo/anual")
def resumo_anual(
    ano: int = Query(default=None),
    db: Session = Depends(get_db),
    _=Depends(get_usuario_atual)
):
    ano = ano or date.today().year
    meses = []
    for mes in range(1, 13):
        inicio = datetime(ano, mes, 1)
        fim = datetime(ano, mes + 1, 1) if mes < 12 else datetime(ano + 1, 1, 1)
        receitas = db.query(func.sum(models.Lancamento.valor)).filter(
            models.Lancamento.tipo == models.TipoLancamento.receita,
            models.Lancamento.data >= inicio, models.Lancamento.data < fim
        ).scalar() or 0
        despesas = db.query(func.sum(models.Lancamento.valor)).filter(
            models.Lancamento.tipo == models.TipoLancamento.despesa,
            models.Lancamento.data >= inicio, models.Lancamento.data < fim
        ).scalar() or 0
        meses.append({"mes": mes, "receitas": receitas, "despesas": despesas, "saldo": receitas - despesas})
    return meses
