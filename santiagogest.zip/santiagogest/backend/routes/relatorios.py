from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from datetime import datetime, date
from database import get_db
import models
from auth import get_usuario_atual

router = APIRouter()

@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), _=Depends(get_usuario_atual)):
    hoje = date.today()
    inicio_hoje = datetime.combine(hoje, datetime.min.time())

    # Faturamento hoje
    fat_hoje = db.query(func.sum(models.Venda.total)).filter(
        models.Venda.criado_em >= inicio_hoje,
        models.Venda.status == models.StatusVenda.finalizada
    ).scalar() or 0

    vendas_hoje = db.query(func.count(models.Venda.id)).filter(
        models.Venda.criado_em >= inicio_hoje,
        models.Venda.status == models.StatusVenda.finalizada
    ).scalar() or 0

    # Total produtos e alertas
    total_produtos = db.query(func.count(models.Produto.id)).filter(models.Produto.ativo == True).scalar()
    estoque_critico = db.query(func.count(models.Estoque.id)).filter(
        models.Estoque.quantidade <= models.Estoque.quantidade_minima
    ).scalar()

    # Saldo caixa (lançamentos pagos)
    receitas = db.query(func.sum(models.Lancamento.valor)).filter(
        models.Lancamento.tipo == models.TipoLancamento.receita,
        models.Lancamento.pago == True
    ).scalar() or 0
    despesas = db.query(func.sum(models.Lancamento.valor)).filter(
        models.Lancamento.tipo == models.TipoLancamento.despesa,
        models.Lancamento.pago == True
    ).scalar() or 0

    return {
        "faturamento_hoje": fat_hoje,
        "vendas_hoje": vendas_hoje,
        "ticket_medio": fat_hoje / vendas_hoje if vendas_hoje else 0,
        "saldo_caixa": receitas - despesas,
        "total_produtos": total_produtos,
        "estoque_critico": estoque_critico,
    }

@router.get("/produtos-mais-vendidos")
def produtos_mais_vendidos(
    data_inicio: date = None,
    data_fim: date = None,
    limit: int = 10,
    db: Session = Depends(get_db),
    _=Depends(get_usuario_atual)
):
    q = db.query(
        models.ItemVenda.produto_id,
        models.Produto.nome,
        func.sum(models.ItemVenda.quantidade).label("quantidade_total"),
        func.sum(models.ItemVenda.total).label("valor_total")
    ).join(models.Produto).join(models.Venda).filter(
        models.Venda.status == models.StatusVenda.finalizada
    )
    if data_inicio:
        q = q.filter(models.Venda.criado_em >= datetime.combine(data_inicio, datetime.min.time()))
    if data_fim:
        q = q.filter(models.Venda.criado_em <= datetime.combine(data_fim, datetime.max.time()))

    resultado = q.group_by(models.ItemVenda.produto_id, models.Produto.nome)\
        .order_by(desc("valor_total")).limit(limit).all()

    return [{"produto_id": r[0], "nome": r[1], "quantidade_total": r[2], "valor_total": r[3]} for r in resultado]

@router.get("/vendas-por-periodo")
def vendas_por_periodo(
    data_inicio: date = None,
    data_fim: date = None,
    db: Session = Depends(get_db),
    _=Depends(get_usuario_atual)
):
    q = db.query(
        func.date(models.Venda.criado_em).label("data"),
        func.count(models.Venda.id).label("quantidade"),
        func.sum(models.Venda.total).label("total")
    ).filter(models.Venda.status == models.StatusVenda.finalizada)
    if data_inicio:
        q = q.filter(models.Venda.criado_em >= datetime.combine(data_inicio, datetime.min.time()))
    if data_fim:
        q = q.filter(models.Venda.criado_em <= datetime.combine(data_fim, datetime.max.time()))

    resultado = q.group_by(func.date(models.Venda.criado_em)).order_by("data").all()
    return [{"data": str(r[0]), "quantidade": r[1], "total": r[2]} for r in resultado]

@router.get("/posicao-estoque")
def posicao_estoque(db: Session = Depends(get_db), _=Depends(get_usuario_atual)):
    estoques = db.query(models.Estoque).join(models.Produto).filter(models.Produto.ativo == True).all()
    return [
        {
            "produto_id": e.produto_id,
            "nome": e.produto.nome,
            "codigo_barras": e.produto.codigo_barras,
            "quantidade": e.quantidade,
            "quantidade_minima": e.quantidade_minima,
            "preco_custo": e.produto.preco_custo,
            "preco_venda": e.produto.preco_venda,
            "valor_estoque": e.quantidade * e.produto.preco_custo,
            "status": "esgotado" if e.quantidade <= 0 else ("critico" if e.quantidade <= e.quantidade_minima else "normal")
        }
        for e in estoques
    ]

@router.get("/notas-fiscais")
def listar_notas(
    skip: int = 0, limit: int = 50,
    db: Session = Depends(get_db),
    _=Depends(get_usuario_atual)
):
    notas = db.query(models.NotaFiscal).order_by(models.NotaFiscal.criado_em.desc()).offset(skip).limit(limit).all()
    return [
        {
            "id": n.id, "numero": n.numero, "serie": n.serie,
            "chave_acesso": n.chave_acesso, "status": n.status,
            "venda_id": n.venda_id, "criado_em": n.criado_em
        }
        for n in notas
    ]

@router.post("/notas-fiscais/{venda_id}/emitir")
def emitir_nfe(venda_id: int, db: Session = Depends(get_db), usuario=Depends(get_usuario_atual)):
    """Endpoint para integração com SEFAZ (requer certificado digital)"""
    venda = db.query(models.Venda).filter(models.Venda.id == venda_id).first()
    if not venda:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Venda não encontrada")

    nota = db.query(models.NotaFiscal).filter(models.NotaFiscal.venda_id == venda_id).first()
    if not nota:
        # Conta o próximo número
        ultimo = db.query(func.max(models.NotaFiscal.numero)).scalar()
        proximo = str(int(ultimo or "0") + 1).zfill(6)
        nota = models.NotaFiscal(
            venda_id=venda_id,
            numero=proximo,
            status=models.StatusNFe.pendente
        )
        db.add(nota)
        db.commit()
        db.refresh(nota)

    # INTEGRAÇÃO SEFAZ: adicione aqui a biblioteca pynfe ou focusnfe
    return {"mensagem": "NF-e em processamento", "numero": nota.numero, "status": nota.status}
